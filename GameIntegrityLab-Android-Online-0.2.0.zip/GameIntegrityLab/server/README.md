# Isolated staging reference API

This FastAPI fixture demonstrates a safe client/server trust boundary. The Android app sends a test claim of `WIN`; this server always returns its own fixture outcome (`LOSE`) and explicitly reports `client_claim_used: false`.

**Do not deploy this demo as a public or production game service.** Keep it on localhost, a private network, or an access-controlled staging environment. It has no user authentication, durable replay database, rate limiting, or production-grade audit storage.

Run:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

For an Android emulator, `10.0.2.2` maps to the host machine, but the Android app intentionally requires HTTPS. Put a trusted TLS reverse proxy in front of the API for device testing. Do not weaken TLS validation or use a public production endpoint.

## Request
`POST /v1/test/round`, header `X-GIL-Test: authorized-staging`, JSON:
```json
{"test_session":"gil-staging-session-001","client_outcome":"WIN","request_id":"<uuid>"}
```

The response includes `server_outcome`, `client_claim_received`, and `client_claim_used`. In a real authorized staging integration, replace this fixture with your own server-side game logic and enforce authentication, authorization, idempotency/nonces, replay protection, rate limits, and immutable audit logs.
