from datetime import datetime, timezone
from uuid import UUID
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Game Integrity Lab Staging API", version="0.2.0")

class RoundRequest(BaseModel):
    test_session: str = Field(min_length=8, max_length=100)
    client_outcome: str | None = Field(default=None, pattern="^(WIN|LOSE)$")
    request_id: str

@app.post("/v1/test/round")
def create_round(body: RoundRequest, x_gil_test: str | None = Header(default=None)):
    # This reference endpoint is a deliberately isolated QA fixture.
    # It is NOT a production game endpoint and must not be exposed publicly.
    if x_gil_test != "authorized-staging":
        raise HTTPException(status_code=403, detail="Missing staging test header")
    try:
        UUID(body.request_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="request_id must be a UUID")

    # Deterministic fixture: server chooses LOSE regardless of client claim.
    # A real game must compute outcomes from trusted server-side game state/RNG.
    server_outcome = "LOSE"
    return {
        "round_id": "gil-demo-round",
        "request_id": body.request_id,
        "server_outcome": server_outcome,
        "client_claim_received": body.client_outcome,
        "client_claim_used": False,
        "issued_at": datetime.now(timezone.utc).isoformat(),
    }

@app.get("/health")
def health():
    return {"status": "ok", "environment": "isolated-staging-demo"}
