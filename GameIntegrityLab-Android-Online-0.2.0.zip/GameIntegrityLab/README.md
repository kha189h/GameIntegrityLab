# Game Integrity Lab (Android MVP)

An authorized QA/security test harness for **your own game or a staging environment**.

## Version 0.2.0 — online staging test
- Sends a test-only `WIN` client claim to a configured HTTPS staging endpoint.
- Checks that the staging server returns its own outcome and `client_claim_used=false`.
- Requires the exact `/v1/test/round` path and HTTPS.
- Never logs in to, hooks, modifies, or changes outcomes in VAN88 or another live third-party game.

## What this MVP does
- Runs offline simulated rounds with selectable WIN/LOSE outcomes.
- Demonstrates the key integrity rule: a client-supplied outcome is untrusted.
- Runs a mock authoritative-server test that ignores a forged client outcome.
- Shows basic APK/runtime integrity indicators (debuggable build, emulator hint, debugger attached).
- Exports a JSON test report through Android's share sheet.

## What it deliberately does not do
- It does not hook, modify, inject into, or manipulate VAN88 or any third-party live game.
- It does not capture credentials, automate logins, intercept traffic, or send modified outcomes to a production service.
- The WIN/LOSE selector affects only the **offline simulator**. The mock-server test is deterministic and demonstrates rejection of client authority.

## Build
Open this repository in Android Studio (Hedgehog or newer), or use GitHub Actions:
1. Push this folder to a GitHub repository.
2. Open **Actions** and run `Android CI`.
3. Download the `game-integrity-lab-debug-apk` artifact.

Local build:
```bash
./gradlew assembleDebug
```
The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Project layout
- `app/`: Android app (Kotlin + Jetpack Compose)
- `server/`: optional FastAPI reference backend for a staging test environment
- `.github/workflows/android.yml`: GitHub Actions build

## Configure online staging test
1. Deploy `server/` only in a private, authorized staging environment. The included API is a deterministic demo fixture, not production-ready.
2. Configure a trusted HTTPS URL ending in `/v1/test/round` in the Android app.
3. Enter a non-secret test session identifier (at least 8 characters).
4. Tap **Chạy online staging test**. The app sends a test claim of `WIN`; the demo server returns its own fixture result (`LOSE`) and `client_claim_used=false`.
5. Export the JSON report.

The Android app sends no VAN88 credentials, cookies, or live-game requests.

## Next step for a real authorized assessment
Connect only to a staging endpoint that you own/control. Implement authentication with short-lived test credentials, server-side authorization, request IDs/nonces, replay protection, server-authoritative outcomes, and auditable test logs. Do not place production secrets in the APK.
