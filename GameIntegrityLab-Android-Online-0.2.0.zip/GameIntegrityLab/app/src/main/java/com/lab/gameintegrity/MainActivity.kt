package com.lab.gameintegrity

import android.content.ClipData
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Bundle
import android.os.Debug
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private const val SDK_P = 28

data class TestEvent(val name: String, val status: String, val detail: String,
                     val time: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GameIntegrityScreen() } }
    }
}

@Composable
private fun GameIntegrityScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var desired by remember { mutableStateOf("WIN") }
    var simulated by remember { mutableStateOf("Chưa chạy") }
    var endpoint by remember { mutableStateOf("https://YOUR-STAGING-HOST/v1/test/round") }
    var testSession by remember { mutableStateOf("gil-staging-session-001") }
    var onlineStatus by remember { mutableStateOf("Chưa chạy") }
    var onlineDetail by remember { mutableStateOf("Chỉ gửi yêu cầu tới endpoint staging do bạn sở hữu/được cấp quyền.") }
    var busy by remember { mutableStateOf(false) }
    val events = remember { mutableStateListOf<TestEvent>() }

    fun add(name: String, status: String, detail: String) {
        events.add(0, TestEvent(name, status, detail))
    }

    fun runOnlineTest() {
        val target = endpoint.trim()
        val session = testSession.trim()
        if (!target.startsWith("https://") || !target.endsWith("/v1/test/round")) {
            onlineStatus = "INVALID CONFIG"
            onlineDetail = "Endpoint phải dùng HTTPS và kết thúc bằng /v1/test/round. Không dùng URL production."
            add("Online staging test", "INVALID", onlineDetail)
            return
        }
        if (session.length < 8) {
            onlineStatus = "INVALID CONFIG"
            onlineDetail = "Test session phải có ít nhất 8 ký tự."
            add("Online staging test", "INVALID", onlineDetail)
            return
        }
        busy = true
        onlineStatus = "RUNNING"
        onlineDetail = "Đang gửi test claim WIN tới staging..."
        scope.launch {
            val result = withContext(Dispatchers.IO) { postStagingTest(target, session) }
            busy = false
            onlineStatus = result.first
            onlineDetail = result.second
            add("Online staging test", result.first, result.second)
        }
    }

    val appInfo = context.applicationInfo
    val debuggable = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    val debugger = Debug.isDebuggerConnected()
    val emulator = Build.FINGERPRINT.startsWith("generic") || Build.MODEL.contains("Emulator", true) ||
        Build.HARDWARE.contains("goldfish", true) || Build.HARDWARE.contains("ranchu", true)
    val certHash = remember {
        runCatching {
            val pkgInfo = if (Build.VERSION.SDK_INT >= SDK_P) {
                context.packageManager.getPackageInfo(context.packageName,
                    android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName,
                    android.content.pm.PackageManager.GET_SIGNATURES)
            }
            val bytes = if (Build.VERSION.SDK_INT >= SDK_P) pkgInfo.signingInfo.apkContentsSigners.first().toByteArray()
            else {
                @Suppress("DEPRECATION")
                pkgInfo.signatures.first().toByteArray()
            }
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02X".format(it) }
        }.getOrElse { "Unavailable: ${it.javaClass.simpleName}" }
    }

    fun exportReport() {
        val json = JSONObject().apply {
            put("app", "Game Integrity Lab")
            put("version", "0.2.0")
            put("generatedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
            put("device", JSONObject().apply {
                put("manufacturer", Build.MANUFACTURER); put("model", Build.MODEL); put("sdk", Build.VERSION.SDK_INT)
                put("emulatorHint", emulator); put("debuggerAttached", debugger); put("debuggableBuild", debuggable)
                put("signingCertificateSha256", certHash)
            })
            put("offlineSimulation", JSONObject().apply { put("selectedOutcome", desired); put("lastOutcome", simulated) })
            put("onlineStagingTest", JSONObject().apply {
                put("endpoint", endpoint); put("status", onlineStatus); put("detail", onlineDetail)
            })
            put("events", JSONArray().apply { events.forEach { e -> put(JSONObject().apply {
                put("time", e.time); put("name", e.name); put("status", e.status); put("detail", e.detail)
            }) } })
        }.toString(2)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"; putExtra(Intent.EXTRA_SUBJECT, "Game Integrity Lab report")
            putExtra(Intent.EXTRA_TEXT, json); clipData = ClipData.newPlainText("GIL report", json)
        }
        context.startActivity(Intent.createChooser(send, "Export test report"))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("GAME INTEGRITY LAB", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Android QA harness • Offline + authorized staging", style = MaterialTheme.typography.bodyMedium)

        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("01 / Offline simulator", fontWeight = FontWeight.Bold)
            Text("Chọn kết quả chỉ để mô phỏng giao diện và luồng xử lý cục bộ.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = desired == "WIN", onClick = { desired = "WIN" }, label = { Text("WIN") })
                FilterChip(selected = desired == "LOSE", onClick = { desired = "LOSE" }, label = { Text("LOSE") })
            }
            Button(onClick = { simulated = desired; add("Offline simulator", "PASS", "Đã mô phỏng $desired cục bộ; không gửi tới game thật.") }, modifier = Modifier.fillMaxWidth()) { Text("Chạy mô phỏng") }
            Text("Kết quả: $simulated", fontWeight = FontWeight.SemiBold)
        } }

        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("02 / Online staging integrity test", fontWeight = FontWeight.Bold)
            Text("Gửi client_claim WIN tới API test của bạn. Server staging phải tự quyết định kết quả và trả client_claim_used=false.")
            OutlinedTextField(value = endpoint, onValueChange = { endpoint = it }, label = { Text("HTTPS staging endpoint") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = testSession, onValueChange = { testSession = it }, label = { Text("Test session ID (không phải mật khẩu)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { runOnlineTest() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Đang kiểm thử..." else "Chạy online staging test") }
            Text("Trạng thái: $onlineStatus", fontWeight = FontWeight.Bold)
            Text(onlineDetail)
            Text("Chỉ dùng endpoint staging thuộc quyền kiểm thử. Không nhập URL game production, cookie hay thông tin đăng nhập.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        } }

        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("03 / Runtime integrity signals", fontWeight = FontWeight.Bold)
            Signal("Debuggable build", if (debuggable) "YES" else "NO")
            Signal("Debugger attached", if (debugger) "YES" else "NO")
            Signal("Emulator heuristic", if (emulator) "YES" else "NO")
            Text("Signing certificate SHA-256", fontWeight = FontWeight.SemiBold)
            Text(certHash, style = MaterialTheme.typography.bodySmall)
            Text("Đây là tín hiệu hỗ trợ QA, không phải bằng chứng tuyệt đối thiết bị an toàn.", style = MaterialTheme.typography.bodySmall)
        } }

        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("04 / Test log", fontWeight = FontWeight.Bold)
            if (events.isEmpty()) Text("Chưa có sự kiện kiểm thử.")
            events.take(15).forEach { e ->
                HorizontalDivider()
                Text("${e.time} • ${e.status} • ${e.name}", fontWeight = FontWeight.SemiBold)
                Text(e.detail, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = { events.clear() }, modifier = Modifier.fillMaxWidth()) { Text("Xóa log") }
        } }
        Button(onClick = { exportReport() }, modifier = Modifier.fillMaxWidth()) { Text("Xuất báo cáo JSON") }
    }
}

private fun postStagingTest(endpoint: String, session: String): Pair<String, String> {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 10_000; readTimeout = 10_000
            doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json"); setRequestProperty("X-GIL-Test", "authorized-staging")
        }
        val requestId = UUID.randomUUID().toString()
        val body = JSONObject().apply {
            put("test_session", session); put("client_outcome", "WIN"); put("request_id", requestId)
        }.toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) return "HTTP $code" to "Staging API trả lỗi: ${responseText.take(500)}"
        val response = JSONObject(responseText)
        val usedClaim = response.optBoolean("client_claim_used", true)
        val serverOutcome = response.optString("server_outcome", "UNKNOWN")
        val echoedClaim = response.optString("client_claim_received", "UNKNOWN")
        if (!usedClaim && serverOutcome in listOf("WIN", "LOSE")) {
            "PASS" to "Server trả kết quả $serverOutcome; đã nhận claim $echoedClaim nhưng không dùng claim làm kết quả. Request ID: $requestId"
        } else {
            "REVIEW" to "Không xác minh được server bỏ qua client claim. client_claim_used=$usedClaim; server_outcome=$serverOutcome. Cần rà soát API và log server."
        }
    } catch (e: Exception) {
        "ERROR" to "Không kết nối được staging API: ${e.javaClass.simpleName}: ${e.message ?: "unknown error"}"
    } finally { connection?.disconnect() }
}

@Composable
private fun Signal(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, fontWeight = FontWeight.Bold)
    }
}
