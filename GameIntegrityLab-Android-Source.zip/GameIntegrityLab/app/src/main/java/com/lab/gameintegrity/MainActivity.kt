package com.lab.gameintegrity

import android.content.ClipData
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.os.Debug
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class TestEvent(
    val name: String,
    val status: String,
    val detail: String,
    val time: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GameIntegrityScreen() } }
    }
}

@Composable
private fun GameIntegrityScreen() {
    val context = LocalContext.current
    var desired by remember { mutableStateOf("WIN") }
    var simulated by remember { mutableStateOf("Chưa chạy") }
    var serverResult by remember { mutableStateOf("Chưa chạy") }
    var serverDetail by remember { mutableStateOf("Chạy bài test để xem server xử lý kết quả giả mạo.") }
    val events = remember { mutableStateListOf<TestEvent>() }

    fun add(name: String, status: String, detail: String) {
        events.add(0, TestEvent(name, status, detail))
    }

    fun runClientSimulation() {
        simulated = desired
        add("Offline simulator", "PASS", "Đã mô phỏng kết quả $desired. Chỉ là dữ liệu cục bộ, không gửi tới game thật.")
    }

    fun runAuthorityTest() {
        // Test fixture: the client claims WIN, but the authoritative test server decides LOSE.
        val clientClaim = "WIN"
        val authoritative = "LOSE"
        val accepted = authoritative // Server ignores clientClaim.
        val passed = accepted != clientClaim
        serverResult = if (passed) "PASS" else "FAIL"
        serverDetail = "Client gửi '$clientClaim'; server kiểm thử trả '$accepted'. Kết quả client không được tin cậy."
        add("Server-authority test", serverResult, serverDetail)
    }

    val appInfo = context.applicationInfo
    val debuggable = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    val debugger = Debug.isDebuggerConnected()
    val emulator = (Build.FINGERPRINT.startsWith("generic") ||
        Build.MODEL.contains("Emulator", true) ||
        Build.HARDWARE.contains("goldfish", true) ||
        Build.HARDWARE.contains("ranchu", true))
    val certHash = remember {
        runCatching {
            val pkgInfo = if (Build.VERSION.SDK_INT >=  P) {
                context.packageManager.getPackageInfo(context.packageName,
                    android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName,
                    android.content.pm.PackageManager.GET_SIGNATURES)
            }
            val bytes = if (Build.VERSION.SDK_INT >= P) {
                pkgInfo.signingInfo.apkContentsSigners.first().toByteArray()
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.signatures.first().toByteArray()
            }
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02X".format(it) }
        }.getOrElse { "Unavailable: ${it.javaClass.simpleName}" }
    }

    fun exportReport() {
        val json = JSONObject().apply {
            put("app", "Game Integrity Lab")
            put("version", "0.1.0")
            put("generatedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
            put("device", JSONObject().apply {
                put("manufacturer", Build.MANUFACTURER)
                put("model", Build.MODEL)
                put("sdk", Build.VERSION.SDK_INT)
                put("emulatorHint", emulator)
                put("debuggerAttached", debugger)
                put("debuggableBuild", debuggable)
                put("signingCertificateSha256", certHash)
            })
            put("simulation", JSONObject().apply {
                put("selectedOutcome", desired)
                put("lastOutcome", simulated)
            })
            put("serverAuthorityTest", JSONObject().apply {
                put("status", serverResult)
                put("detail", serverDetail)
            })
            put("events", JSONArray().apply {
                events.forEach { e -> put(JSONObject().apply {
                    put("time", e.time); put("name", e.name); put("status", e.status); put("detail", e.detail)
                }) }
            })
        }.toString(2)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "Game Integrity Lab report")
            putExtra(Intent.EXTRA_TEXT, json)
            clipData = ClipData.newPlainText("GIL report", json)
        }
        context.startActivity(Intent.createChooser(send, "Export test report"))
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("GAME INTEGRITY LAB", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Android QA harness • Offline simulator + integrity checks", style = MaterialTheme.typography.bodyMedium)
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("01 / Offline game simulator", fontWeight = FontWeight.Bold)
                Text("Chọn kết quả để kiểm thử giao diện và luồng xử lý trong simulator. Không tác động game trực tuyến.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = desired == "WIN", onClick = { desired = "WIN" }, label = { Text("WIN") })
                    FilterChip(selected = desired == "LOSE", onClick = { desired = "LOSE" }, label = { Text("LOSE") })
                }
                Button(onClick = { runClientSimulation() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Chạy mô phỏng")
                }
                Text("Kết quả mô phỏng: $simulated", fontWeight = FontWeight.SemiBold)
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("02 / Server-authority test", fontWeight = FontWeight.Bold)
                Text("Bài test giả lập client khai báo WIN nhưng server kiểm thử phải tự quyết định kết quả.")
                Button(onClick = { runAuthorityTest() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Kiểm tra server có tin client không")
                }
                Text("Trạng thái: $serverResult", fontWeight = FontWeight.Bold)
                Text(serverDetail)
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("03 / Runtime integrity signals", fontWeight = FontWeight.Bold)
                Signal("Debuggable build", if (debuggable) "YES" else "NO")
                Signal("Debugger attached", if (debugger) "YES" else "NO")
                Signal("Emulator heuristic", if (emulator) "YES" else "NO")
                Text("Signing certificate SHA-256", fontWeight = FontWeight.SemiBold)
                Text(certHash, style = MaterialTheme.typography.bodySmall)
                Text("Các tín hiệu này chỉ hỗ trợ QA; không phải bằng chứng tuyệt đối về thiết bị an toàn.")
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("04 / Test log", fontWeight = FontWeight.Bold)
                if (events.isEmpty()) Text("Chưa có sự kiện kiểm thử.")
                events.take(12).forEach { e ->
                    HorizontalDivider()
                    Text("${e.time} • ${e.status} • ${e.name}", fontWeight = FontWeight.SemiBold)
                    Text(e.detail, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(onClick = { events.clear() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Xóa log")
                }
            }
        }
        Button(onClick = { exportReport() }, modifier = Modifier.fillMaxWidth()) {
            Text("Xuất báo cáo JSON")
        }
        Text("Chỉ dùng trên ứng dụng/hệ thống bạn sở hữu hoặc được ủy quyền kiểm thử.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
    }
}

private const val P = 28

@Composable
private fun Signal(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
