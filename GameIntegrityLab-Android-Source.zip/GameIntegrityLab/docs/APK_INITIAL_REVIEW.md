# VAN88-20261012.apk — initial static inventory

Source inspected: the uploaded APK at the time this project was generated.

## Confirmed from the package container
- Android APK archive.
- `classes.dex` is present.
- `assets/index.android.bundle` is present (about 1.85 MB).
- Native libraries include React Native/Hermes-related components, including `libreactnative.so`, `libhermesvm.so`, `libjsi.so`, and `libfbjni.so`, for multiple ABIs (arm64-v8a, armeabi-v7a, x86, x86_64).
- `AndroidManifest.xml` and `resources.arsc` are present.
- AppsFlyer-related assets are present.

## Strings observed in the bundle
The following path-like strings were found:
- `/api/v1/User/DeviceLoginRequest`
- `/api/v1/Domain/GetPortalDomain`
- `/api/v2/Domain/InvalidDomainNotify`

These are string observations only. They do not establish that the endpoints are reachable, currently active, or vulnerable. No credentials were used and no requests were sent to VAN88.

## Not established by this initial pass
- Actual server-side game outcome logic.
- Authentication/session security.
- WebSocket endpoints or message schema.
- Whether outcomes are generated client-side or server-side.
- Any exploitable vulnerability.

## Recommended authorized next steps
1. Obtain written scope and a dedicated staging account/environment.
2. Decompile the manifest/resources and inspect DEX/bundle with JADX, MobSF, and Hermes-aware tooling.
3. Map network calls only in the authorized staging environment.
4. Test server-authoritative outcome enforcement, replay protection, request signing, authorization, and audit logging.
5. Record evidence and report findings without changing production game outcomes.
