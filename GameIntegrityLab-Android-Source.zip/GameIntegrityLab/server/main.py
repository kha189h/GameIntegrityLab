from fastapi import FastAPI
from pydantic import BaseModel, Field
from uuid import uuid4
from datetime import datetime, timezone
import secrets

app = FastAPI(title="Game Integrity Lab Staging API", version="0.1.0")

class RoundRequest(BaseModel):
    test_session: str = Field(min_length=8, max_length=100)
    client_outcome: str | None = Field(default=None, pattern="^(WIN|LOSE)$")
    request_id: str = Field(min_length=8, max_length=100)

@app.post("/v1/test/round")
def create_round(body: RoundRequest):
    # Idempotency/replay storage must be added for a real deployment.
    # This demo deliberately does NOT trust body.client_outcome.
    server_outcome = secrets.choice(["WIN", "LOSE"])
    return {
        "round_id": str(uuid4()),
        "request_id": body.request_id,
        "server_outcome": server_outcome,
        "client_claim_received": body.client_outcome,
        "client_claim_used": False,
        "issued_at": datetime.now(timezone.utc).isoformat(),
    }

@app.get("/health")
def health():
    return {"status": "ok"}
