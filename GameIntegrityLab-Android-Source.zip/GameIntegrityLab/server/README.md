# Optional staging reference API

This small FastAPI example demonstrates the correct trust boundary: the server chooses the outcome; it never accepts `client_outcome` as authoritative.

Run:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Only expose this on a private test network. This is a teaching fixture, not a production game backend.
